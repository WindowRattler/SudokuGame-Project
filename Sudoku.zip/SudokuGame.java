import java.util.ArrayList;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Collections;


//Class meant to setup and maintain a game of sudoku
//Contributers: Nicholas Rouse, Benjamin Kramer
//Remember to leave detailed comments
//Reminder that java 2d arrays are [y][x]
public class SudokuGame {
	private int[][] box1 = new int[3][3];
	private int[][] box2 = new int[3][3];
	private int[][] box3 = new int[3][3];
	private int[][] box4 = new int[3][3];
	private int[][] box5 = new int[3][3];
	private int[][] box6 = new int[3][3];
	private int[][] box7 = new int[3][3];
	private int[][] box8 = new int[3][3];
	private int[][] box9 = new int[3][3];
	private int[][][] board = new int[][][] {box1, box2, box3, box4, box5, box6, box7, box8, box9};//Working board
	private int[][][] emptyBoard = new int[9][3][3]; //To reset board
	private int[][][] fullBoard = new int[9][3][3];//To be filled immediately
	private int[][][] startBoard = new int[9][3][3];//Remembers what the board started as
	private boolean[][][] editable = new boolean[9][3][3];//Editable board positions (true = editable)
	private ArrayList<Integer> sudokuNumbers = new ArrayList<Integer>();//Holds the numbers 1 - 9 for filling other arrays
	//Initialize scanner
	Scanner scanner = new Scanner(System.in);
	//TODO Make an array that remembers the initial setup of the array
	//For debugging purposes
	private ArrayList<Integer> checkedRowNumbers = new ArrayList<Integer>();
	private ArrayList<Integer> checkedColumnNumbers = new ArrayList<Integer>();
	private int debugi;
	
	public SudokuGame(int difficulty)
	{
		sudokuNumbers.add(1);//Initialize Sudoku Numbers
		sudokuNumbers.add(2);
		sudokuNumbers.add(3);
		sudokuNumbers.add(4);
		sudokuNumbers.add(5);
		sudokuNumbers.add(6);
		sudokuNumbers.add(7);
		sudokuNumbers.add(8);
		sudokuNumbers.add(9);
		initializeEditableArray();//Fills editable with false values
		initializeBoard(difficulty);
	}
	
	public SudokuGame()
	{
		//Creates a blank game
		sudokuNumbers.add(1);//Initialize Sudoku Numbers
		sudokuNumbers.add(2);
		sudokuNumbers.add(3);
		sudokuNumbers.add(4);
		sudokuNumbers.add(5);
		sudokuNumbers.add(6);
		sudokuNumbers.add(7);
		sudokuNumbers.add(8);
		sudokuNumbers.add(9);
		initializeEditableArray();//Fills editable with false values
		makeFullBoard();
	}
	
	//Fills editable with false
	private void initializeEditableArray()
	{
		//Loops through editable
		for(boolean[][] twoDEditable : editable)
		{
			for(boolean[] oneDEditable : twoDEditable)
			{
				Arrays.fill(oneDEditable, false);
			}
		}
	}
	
	//fills all spaces in the board with a completed game
	public void fullGame()
	{
		modifyElement(0, 0, 0, 4);//Makes a completed game
		modifyElement(0, 0, 1, 7);
		modifyElement(0, 0, 2, 8);
		modifyElement(0, 1, 0, 6);
		modifyElement(0, 1, 1, 9);
		modifyElement(0, 1, 2, 3);
		modifyElement(0, 2, 0, 5);
		modifyElement(0, 2, 1, 2);
		modifyElement(0, 2, 2, 1);
		modifyElement(1, 0, 0, 3);
		modifyElement(1, 0, 1, 9);
		modifyElement(1, 0, 2, 2);
		modifyElement(1, 1, 0, 7);
		modifyElement(1, 1, 1, 1);
		modifyElement(1, 1, 2, 5);
		modifyElement(1, 2, 0, 4);
		modifyElement(1, 2, 1, 6);
		modifyElement(1, 2, 2, 8);
		modifyElement(2, 0, 0, 6);
		modifyElement(2, 0, 1, 5);
		modifyElement(2, 0, 2, 1);
		modifyElement(2, 1, 0, 4);
		modifyElement(2, 1, 1, 2);
		modifyElement(2, 1, 2, 8);
		modifyElement(2, 2, 0, 3);
		modifyElement(2, 2, 1, 9);
		modifyElement(2, 2, 2, 7);
		modifyElement(3, 0, 0, 1);
		modifyElement(3, 0, 1, 6);
		modifyElement(3, 0, 2, 5);
		modifyElement(3, 1, 0, 3);
		modifyElement(3, 1, 1, 4);
		modifyElement(3, 1, 2, 9);
		modifyElement(3, 2, 0, 7);
		modifyElement(3, 2, 1, 8);
		modifyElement(3, 2, 2, 2);
		modifyElement(4, 0, 0, 8);
		modifyElement(4, 0, 1, 2);
		modifyElement(4, 0, 2, 4);
		modifyElement(4, 1, 0, 1);
		modifyElement(4, 1, 1, 5);
		modifyElement(4, 1, 2, 7);
		modifyElement(4, 2, 0, 6);
		modifyElement(4, 2, 1, 3);
		modifyElement(4, 2, 2, 9);
		modifyElement(5, 0, 0, 7);
		modifyElement(5, 0, 1, 3);
		modifyElement(5, 0, 2, 9);
		modifyElement(5, 1, 0, 2);
		modifyElement(5, 1, 1, 8);
		modifyElement(5, 1, 2, 6);
		modifyElement(5, 2, 0, 5);
		modifyElement(5, 2, 1, 1);
		modifyElement(5, 2, 2, 4);
		modifyElement(6, 0, 0, 2);
		modifyElement(6, 0, 1, 5);
		modifyElement(6, 0, 2, 6);
		modifyElement(6, 1, 0, 8);
		modifyElement(6, 1, 1, 1);
		modifyElement(6, 1, 2, 4);
		modifyElement(6, 2, 0, 9);
		modifyElement(6, 2, 1, 3);
		modifyElement(6, 2, 2, 7);
		modifyElement(7, 0, 0, 9);
		modifyElement(7, 0, 1, 4);
		modifyElement(7, 0, 2, 1);
		modifyElement(7, 1, 0, 2);
		modifyElement(7, 1, 1, 7);
		modifyElement(7, 1, 2, 3);
		modifyElement(7, 2, 0, 5);
		modifyElement(7, 2, 1, 8);
		modifyElement(7, 2, 2, 6);
		modifyElement(8, 0, 0, 8);
		modifyElement(8, 0, 1, 7);
		modifyElement(8, 0, 2, 3);
		modifyElement(8, 1, 0, 9);
		modifyElement(8, 1, 1, 6);
		modifyElement(8, 1, 2, 5);
		modifyElement(8, 2, 0, 1);
		modifyElement(8, 2, 1, 4);
		modifyElement(8, 2, 2, 2);
	}
	
	//Returns the game board
	public int[][][] getBoard()
	{
		return board;
	}
	
	public void initializeBoard (int difficulty){
		makeFullBoard();
		printArray();//For debug
		removeClues(difficulty);
		ArrayCopier.copyArray(board, startBoard);//Allows for reseting user changes to the original board
		makeEditableArray();//Makes the editable array
	}
	
	public int[][][] getStartBoard() {
		return startBoard;
	}

	public boolean[][][] getEditable() {
		return editable;
	}

	public void makeEditableArray()
	{
		//Loops through board
		for(int box = 0; box < 9; box++)
		{
			for(int x = 0; x < 3; x++)
			{
				for(int y = 0; y < 3; y++)
				{
					if(board[box][x][y] == 0)
					{
						//Editable is true on spaces with 0
						editable[box][x][y] = true;
					}
					else
					{
						//Editable is false on nonzero spaces
						editable[box][x][y] = false;
					}
				}
			}
		}
	}
	
	//Returns board to before user made any changes
	public void undoChanges()
	{
		ArrayCopier.copyArray(startBoard, board);
	}
	
	//Resets all elements of the board and fullBoard to 0
	public void resetBoard()
	{
		ArrayCopier.copyArray(emptyBoard, board);
		ArrayCopier.copyArray(emptyBoard, startBoard);
		ArrayCopier.copyArray(emptyBoard, fullBoard);
		initializeEditableArray();
	}

	public void solve()
	{
		int[][][] workingBoard = Solver.solve(board);
		ArrayCopier.copyArray(workingBoard, board);
	}
	
	public void slowSolve()
	{
		SlowSolver.slowSolve(board);
	}
	
	//Fills the fullBoard array with a complete sudoku game
	public void makeFullBoard()
	{
		fillDiagonal();
		fillRemaining(1, 0, 0);
		ArrayCopier.copyArray(board, fullBoard);;//Puts all numbers into the full board
	}
	
	//Removes between k and k + 1 elements from each box
	public void removeClues(int k)//k should not exceed 6
	{
		if(k >= 7 || k < 1)
		{
			System.err.println(k + " clues removed makes a game without any valid solutions");
			return;
		}
		//Used to prevent removing from already empty spaces
		ArrayList<Integer> indexes = new ArrayList<Integer>();
		do
		{
			//Resets board
			ArrayCopier.copyArray(fullBoard, board);
			//Loops through boxes
			for(int box = 0; box < 9; box++) {
				indexes.removeAll(indexes);//Empties for next loop
				indexes.addAll(sudokuNumbers);//Adds numbers 1 - 9
				int numRemoved;//Stores number of elements to remove
				numRemoved = (int) Math.floor((Math.random() * 2) + k);
				for(int j = 0; j < numRemoved; j++){
					int x = 0;
					int y = 0;
					//Loop to only change spaces not previously changed
					//To break out of loop
					boolean indexLoop = true;
					while(indexLoop)
					{
						x = (int) Math.floor((Math.random() * 3));
						y = (int) Math.floor((Math.random() * 3));
						//Prevents already changed elements from being changed again
						switch(x + (3 * y))//determines position
						{
						case 0:
							if(indexes.contains(Integer.valueOf(1)))//Only if not used
							{
								indexes.remove(Integer.valueOf(1));//prevent being used again
								indexLoop = false;//Breaks loop
								break;
							}
							else
							{
								;//Try again
								break;
							}
						case 1:
							if(indexes.contains(Integer.valueOf(2)))//Only if not used
							{
								indexes.remove(Integer.valueOf(2));//prevent being used again
								indexLoop = false;//Breaks loop
								break;
							}
							else
							{
								;//Try again
								break;
							}
						case 2:
							if(indexes.contains(Integer.valueOf(3)))//Only if not used
							{
								indexes.remove(Integer.valueOf(3));//prevent being used again
								indexLoop = false;//Breaks loop
								break;
							}
							else
							{
								;//Try again
								break;
							}
						case 3:
							if(indexes.contains(Integer.valueOf(4)))//Only if not used
							{
								indexes.remove(Integer.valueOf(4));//prevent being used again
								indexLoop = false;//Breaks loop
								break;
							}
							else
							{
								;//Try again
								break;
							}
						case 4:
							if(indexes.contains(Integer.valueOf(5)))//Only if not used
							{
								indexes.remove(Integer.valueOf(5));//prevent being used again
								indexLoop = false;//Breaks loop
								break;
							}
							else
							{
								;//Try again
								break;
							}
						case 5:
							if(indexes.contains(Integer.valueOf(6)))//Only if not used
							{
								indexes.remove(Integer.valueOf(6));//prevent being used again
								indexLoop = false;//Breaks loop
								break;
							}
							else
							{
								;//Try again
								break;
							}
						case 6:
							if(indexes.contains(Integer.valueOf(7)))//Only if not used
							{
								indexes.remove(Integer.valueOf(7));//prevent being used again
								indexLoop = false;//Breaks loop
								break;
							}
							else
							{
								;//Try again
								break;
							}
						case 7:
							if(indexes.contains(Integer.valueOf(8)))//Only if not used
							{
								indexes.remove(Integer.valueOf(8));//prevent being used again
								indexLoop = false;//Breaks loop
								break;
							}
							else
							{
								;//Try again
								break;
							}
						case 8:
							if(indexes.contains(Integer.valueOf(9)))//Only if not used
							{
								indexes.remove(Integer.valueOf(9));//prevent being used again
								indexLoop = false;//Breaks loop
								break;
							}
							else
							{
								;//Try again
								break;
							}
						}
						modifyElement(box, x, y, 0);//Set element at box to 0
					}
				}
			}
		} while(Solver.solve(board, true) > 1);
	}
	
	//Fills the boxes along the main diagonal \\\
	public void fillDiagonal()
	{
		//Arraylist for unused numbers
		ArrayList<Integer> boxNumbers = new ArrayList<Integer>();
		int value;//for storing value
		for(int box = 0; box <= 8; box += 4)//Loop through boxes along main diagonal
		{
			//Add 1 - 9 to boxNumbers
			boxNumbers.addAll(sudokuNumbers);
			for(int row = 0; row < 3; row++)//Loops through row
			{
				for(int column = 0; column < 3; column ++)//Loops through column
				{
					Collections.shuffle(boxNumbers);//Shuffles arraylist
					value = boxNumbers.get(0);
					boxNumbers.remove(0);//Remove from use
					modifyElement(box, column, row, value);//Add to board
				}
			}
		}
	}

	
	//Recursively fills remaining boxes
	public boolean fillRemaining(int box, int row, int column)
	{
		if(row > 2 && column < 2)//When at end of row
		{
			row = 0;//Reset row
			column++;//Increment column
		}
		if(row > 2 && column >= 2)//When at end of row and end of column
		{
			row = 0;//reset row
			column = 0;//reset column
			box++;//increment box
		}
		if(box == 0 || box == 4)//When at a box along the main diagonal
		{
			box++;
		}
		if(box == 8)
		{
			return true;//Stop recursion
		}
		for(int num = 1; num <= 9; num++)//Loop through 1 through 9
		{
			if(Rules.safeToPlace(board, box, row, column, num))//Checks if safe to place number
			{
				modifyElement(box, column, row, num);//Enter number into board
				//For debug
				//printArray();
				if(fillRemaining(box, row + 1, column))
					return true;
				
				modifyElement(box, column, row, 0);
			}
		}
		return false;
	}
	
	
	@Override
	public String toString()//toString method
	{
		String printedBoard = "";
		for(int box = 0; box <= 2; box++)//Prints first 3 boxes top row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					printedBoard += (Integer.toString(board[box][boxY][0]));
					if(boxY == 2)
						printedBoard += (" | ");//Adds a line every 3 elements
					printedBoard += (" ");//Space between elements
			}
			if(box == 2)
			{
				printedBoard += ("\n");//Newline at end of row
			}
		}
		for(int box = 0; box <= 2; box++)//Prints first 3 boxes middle row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					printedBoard += (Integer.toString(board[box][boxY][1]));
					if(boxY == 2)
						printedBoard += (" | ");//Adds a line every 3 elements
					printedBoard += (" ");//Space between elements
			}
			if(box == 2)
			{
				printedBoard += ("\n");//Newline at end of row
			}
		}
		for(int box = 0; box <= 2; box++)//Prints first 3 boxes bottom row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					printedBoard += (Integer.toString(board[box][boxY][2]));
					if(boxY == 2)
						printedBoard += (" | ");//Adds a line every 3 elements
					printedBoard += (" ");//Space between elements
			}
			if(box == 2)
			{
				printedBoard += ("\n");//Newline at end of row
			}
		}
		printedBoard += ("\n");//Space between boxes
		for(int box = 3; box <= 5; box++)//Prints middle 3 boxes top row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					printedBoard += (Integer.toString(board[box][boxY][0]));
					if(boxY == 2)
						printedBoard += (" | ");//Adds a line every 3 elements
					printedBoard += (" ");//Space between elements
			}
			if(box == 5)
			{
				printedBoard += ("\n");//Newline at end of row
			}
		}
		for(int box = 3; box <= 5; box++)//Prints middle 3 boxes middle row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					printedBoard += (Integer.toString(board[box][boxY][1]));
					if(boxY == 2)
						printedBoard += (" | ");//Adds a line every 3 elements
					printedBoard += (" ");//Space between elements
			}
			if(box == 5)
			{
				printedBoard += ("\n");//Newline at end of row
			}
		}
		for(int box = 3; box <= 5; box++)//Prints middle 3 boxes bottom row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					printedBoard += (Integer.toString(board[box][boxY][2]));
					if(boxY == 2)
						printedBoard += (" | ");//Adds a line every 3 elements
					printedBoard += (" ");//Space between elements
			}
			if(box == 5)
			{
				printedBoard += ("\n");//Newline at end of row
			}
		}
		printedBoard += ("\n");//Space between boxes
		for(int box = 6; box <= 8; box++)//Prints bottom 3 boxes top row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					printedBoard += (Integer.toString(board[box][boxY][0]));
					if(boxY == 2)
						printedBoard += (" | ");//Adds a line every 3 elements
					printedBoard += (" ");//Space between elements
			}
			if(box == 8)
			{
				printedBoard += ("\n");//Newline at end of row
			}
		}
		for(int box = 6; box <= 8; box++)//Prints bottom 3 boxes middle row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					printedBoard += (Integer.toString(board[box][boxY][1]));
					if(boxY == 2)
						printedBoard += (" | ");//Adds a line every 3 elements
					printedBoard += (" ");//Space between elements
			}
			if(box == 8)
			{
				printedBoard += ("\n");//Newline at end of row
			}
		}
		for(int box = 6; box <= 8; box++)//Prints bottom 3 boxes bottom row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					printedBoard += (Integer.toString(board[box][boxY][2]));
					if(boxY == 2)
						printedBoard += (" | ");//Adds a line every 3 elements
					printedBoard += (" ");//Space between elements
			}
			if(box == 8)
			{
				printedBoard += ("\n");//Newline at end of row
			}
		}
		printedBoard += ("\n");//Space between boxes
		return printedBoard;
	}

	private void printArray()//Prints the array
	{
		for(int box = 0; box <= 2; box++)//Prints first 3 boxes top row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(board[box][boxY][0]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 2)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		for(int box = 0; box <= 2; box++)//Prints first 3 boxes middle row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(board[box][boxY][1]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 2)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		for(int box = 0; box <= 2; box++)//Prints first 3 boxes bottom row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(board[box][boxY][2]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 2)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		System.out.println();//Space between boxes
		for(int box = 3; box <= 5; box++)//Prints middle 3 boxes top row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(board[box][boxY][0]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 5)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		for(int box = 3; box <= 5; box++)//Prints middle 3 boxes middle row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(board[box][boxY][1]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 5)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		for(int box = 3; box <= 5; box++)//Prints middle 3 boxes bottom row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(board[box][boxY][2]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 5)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		System.out.println();//Space between boxes
		for(int box = 6; box <= 8; box++)//Prints bottom 3 boxes top row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(board[box][boxY][0]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 8)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		for(int box = 6; box <= 8; box++)//Prints bottom 3 boxes middle row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(board[box][boxY][1]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 8)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		for(int box = 6; box <= 8; box++)//Prints bottom 3 boxes bottom row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(board[box][boxY][2]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 8)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		System.out.println();//Space between boxes
	}
	
	//Scans board for zeroes and prompts user to modify them
	public void scanBoard() {
		//Initialize variables
		int box = 0;
		int row = 0;
		int column = 0;
		boolean valueCheck = false; 
		while (box <= 8) {
			//iterate row
			while (column <= 2) {
				//iterate column
				while (row <= 2) {
					//check if current array id has a zero
					if (board[box][row][column] == 0) {
						//if yes, ask to change and iterate
						//ask for the user to input a new value
						System.out.print("Please enter a number between 1 and 9 for box " + (box + 1) + ", row " + (column + 1) + ", column "
								+ (row + 1) + ": ");
						//check if that input is valid. Throw exception, ask for new value, and loop if not
						int value = 0;
						do {
							try {
								value = scanner.nextInt();
							} catch (InputMismatchException e) {
								// Catches non-int inputs
								System.err.println("Inputs must be between integers between 1 and 9");
								//Clear scanner buffer
								scanner.nextLine();
								//Retry loop
								continue;
							}
							if (value < 0 || value > 9) {
								valueCheck = false;
								System.out.println("That is not a valid input. Please input a number between 1 and 9.");
							} else {
								valueCheck = true;
							}
						} while (valueCheck == false);
						//modify value and iterate
						modifyElement(box, column, row, value);
						//Prints board after modification
						printArray();
						valueCheck = false;
						row++;
					} else {
						// if no, just iterate
						valueCheck = false;
						row++;
					}
				}
				//set to next row, set column to zero
				column++;
				row = 0;
			}
			//Iterates box
			box++;
			row = 0;
			column = 0;
		}
	}
	
	//Changes the value of the specified element on the board
	public void modifyElement(int box, int boxX, int boxY, int value)
	{
		if(box < 0 || box > 8 || boxX < 0 || boxX > 2 || boxY < 0 || boxY > 2)//Catch out of bounds errors
		{
			System.out.println("Invalid box position");
		}
		else if(value < 0 || value > 9)//Catch invalid values for the board
		{
			System.out.println("Sudoku board values must be between 0 and 9.\n0 should only be used for elements you want to come back to later.");
		}
		else
			board[box][boxY][boxX] = value;
	}

	public int[][][] getFullBoard() {
		return fullBoard;
	}

	public void setFullBoard(int[][][] fullBoard) {
		this.fullBoard = fullBoard;
	}

	public void setBoard(int[][][] board) {
		this.board = board;
	}

	public void setStartBoard(int[][][] startBoard) {
		this.startBoard = startBoard;
	}
}
