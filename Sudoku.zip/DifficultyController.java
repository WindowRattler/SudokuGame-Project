import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.application.Application;

public class DifficultyController {

    @FXML
    private Button easyButton;

    @FXML
    private Button mediumButton;

    @FXML
    private Button hardButton;

    @FXML
    private TextArea descriptionTextArea;

    @FXML
    void buttonMouseExit(MouseEvent event) {
    	//Clear description text
    	descriptionTextArea.setText("");
    }

    @FXML
    void easyButtonClicked(ActionEvent event) {
    	startGame(event, 3);
    }

    @FXML
    void easyButtonMouseOver(MouseEvent event) {
    	//Displays description
    	descriptionTextArea.setText("Five to Six clues per small box.\nTotal number of clues is between 45 and 54.");
    }

    @FXML
    void hardButtonMouseClicked(ActionEvent event) {
    	startGame(event, 5);
    }

    @FXML
    void hardButtonMouseOver(MouseEvent event) {
    	//Displays description
    	descriptionTextArea.setText("Three to Four clues per small box.\nTotal number of clues is between 27 and 36.");
    }

    @FXML
    void mediumButtonMouseClicked(ActionEvent event) {
    	startGame(event, 4);
    }

    @FXML
    void mediumButtonMouseOver(MouseEvent event) {
    	//Displays description
    	descriptionTextArea.setText("Four to Five clues per small box.\nTotal number of clues is between 36 and 45.");
    }

    //Calls game GUI with selected difficulty level
    private void startGame(ActionEvent event,int difficulty)
    {
    	try {
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("SudokuBoard.fxml"));
    		Parent root1 = (Parent) fxmlLoader.load();
    		Stage stage = new Stage();
    		stage.initModality(Modality.APPLICATION_MODAL);
    		stage.initStyle(StageStyle.DECORATED);
    		stage.setTitle("Sudoku");
    		//Passes on difficulty from button
    		fxmlLoader.<SudokuController>getController().initData(difficulty, stage);
    		stage.getIcons().add(new Image("Sudoku.png"));
    		stage.setScene(new Scene(root1));
    		stage.show();
    		// Hide this current window
            ((Node)(event.getSource())).getScene().getWindow().hide();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    }
}
