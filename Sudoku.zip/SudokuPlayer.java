
//Runs a sudoku game
//Contributers: Nicholas Rouse, Benjamin Kramer
//Remember to leave detailed comments
//Reminder that java 2d arrays are [y][x]
public class SudokuPlayer {

	public static void main(String[] args) {
		//For deugging purposes
		//Comment out when not in use
		//debug();
		// Initiates the sudoku game
		SudokuGame newGame = new SudokuGame();
		System.out.println(newGame);
		newGame.scanBoard();
		//newGame.solve();
		System.out.println(newGame);
		SudokuChecker gameCheck = new SudokuChecker(newGame.getBoard());
		gameCheck.boardChecker();
		
	
	}

	//Class for debugging purposes
	public static void debug()
	{
		//Create game with known answer
		SudokuGame debugGame = new SudokuGame(1);
		System.out.println(debugGame);
		//TODO create modification elements to known game picture
		debugGame.scanBoard();
		SudokuChecker debugCheck = new SudokuChecker(debugGame.getBoard());
		debugCheck.boardChecker();
		System.exit(0);//Terminates program after debugging
	}
}