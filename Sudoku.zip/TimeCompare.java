//Class for keeping track of the time elapsed during the sudoku game
import java.util.Timer;
import java.util.TimerTask;

import javafx.scene.control.TextField;

public class TimeCompare extends TimerTask {
	Time2 currentTime;
	Time2 startTime;
	TextField timerField;
	public TimeCompare(Time2 currentTime, Time2 startTime, TextField timerField)
	{
		this.currentTime = currentTime;
		this.startTime = startTime;
		this.timerField = timerField;
	}
	
	public void run()
	{
		timerField.setText(currentTime.compare(startTime));//Sets timer equal to the difference between the two Time2 objects
	}
}
