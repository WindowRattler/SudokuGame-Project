import java.util.ArrayList;
//Class for check whether a Sudoku solution is valid
//Contributers: Nicholas Rouse
//TODO perhaps make these methods static?
public class SudokuChecker {
	private int[][][] board;
	private static ArrayList<Integer> sudokuNumbers = new ArrayList<Integer>();//Holds the numbers need for the checkers later
	
	//Loads default board
	public SudokuChecker(int[][][] board)
	{
		this.board = board;
		sudokuNumbers.add(1);//Initialize Sudoku Numbers
		sudokuNumbers.add(2);
		sudokuNumbers.add(3);
		sudokuNumbers.add(4);
		sudokuNumbers.add(5);
		sudokuNumbers.add(6);
		sudokuNumbers.add(7);
		sudokuNumbers.add(8);
		sudokuNumbers.add(9);
	}
	
	//Loads Sudoku board for checking
	public void loadBoard(int[][][] board)
	{
		this.board = board;
	}
	
	//Staticly checks for valid Sudoku game
	public static boolean boardChecker(int[][][] board)
	{
		sudokuNumbers.add(1);//Initialize Sudoku Numbers
		sudokuNumbers.add(2);
		sudokuNumbers.add(3);
		sudokuNumbers.add(4);
		sudokuNumbers.add(5);
		sudokuNumbers.add(6);
		sudokuNumbers.add(7);
		sudokuNumbers.add(8);
		sudokuNumbers.add(9);
		boolean clearedGame = false;
		if(checkBoxes(board))
		{
			if(checkRows(board))
			{
				if(checkColumns(board))
				{
					clearedGame = true;
				}
			}
		}
		return clearedGame;
	}
	
	//Checks for valid Sudoku game
	public void boardChecker()
	{
		boolean clearedGame = false;
		if(checkBoxes(board))
		{
			if(checkRows(board))
			{
				if(checkColumns(board))
				{
					clearedGame = true;
				}
			}
		}
		
		if(clearedGame)
		{
			System.out.println("Congrats! You cleared the game!");
		}
		else
		{
			System.out.println("One or more of the values are incorrect. Try again.");
		}
	}
	
	//Checks for valid Sudoku Boxes
	//Tested and confirmed working as intended
	private static boolean checkBoxes(int[][][] board)
	{
		boolean clearedBox = true;//Assume boxes pass
		ArrayList<Integer> boxNumbers = new ArrayList<Integer>();//Used for checking all numbers 1 - 9
		for(int box = 0; box < 9; box++)//Loops through boxes
		{
			if(clearedBox == false)//Exits loop as soon as check fails
			{
				break;
			}
			boxNumbers.addAll(sudokuNumbers);//Adds 1 - 9 to boxNumbers
			for(int boxX = 0; boxX < 3; boxX++)//Loops through each colunm of the box
			{
				if(clearedBox == false)//Exits loop as soon as check fails
				{
					break;
				}
				for(int boxY = 0; boxY < 3; boxY++)//Loops through each value in the column
				{
					int value = board[box][boxX][boxY];//Takes value from board
					if(boxNumbers.contains(value))//Checks to make sure a number isn't used twice
					{
						boxNumbers.remove(Integer.valueOf(value));//Removes checked number
					}
					else//If number used twice
					{
						clearedBox = false;//Fails check
						break;//Exits loop
					}
				}
			}
		}
		return clearedBox;
	}
	
	//Checks for valid Sudoku rows
	//Tested and confirmed working as intended
	private static boolean checkRows(int[][][] board)
	{
		boolean clearedRows = true;//Assume rows pass
		ArrayList<Integer> rowNumbersTop = new ArrayList<Integer>();//Used for checking all numbers 1 - 9 in top row
		ArrayList<Integer> rowNumbersMiddle = new ArrayList<Integer>();//Used for checking all numbers 1 - 9 in middle row
		ArrayList<Integer> rowNumbersBottom = new ArrayList<Integer>();//Used for checking all numbers 1 - 9 in bottom row
		for(int box = 0; box <= 8; box++)//Loops through boxes
		{
			if(clearedRows == false)//Exits loop as soon as check fails
			{
				break;
			}
			if(box < 3)//Checks for top 3 boxes
			{
				if(box == 0)//Initialize checkers on first loop
				{
					rowNumbersTop.addAll(sudokuNumbers);
					rowNumbersMiddle.addAll(sudokuNumbers);
					rowNumbersBottom.addAll(sudokuNumbers);//All get values 1 - 9 added to them
				}
				for(int boxY = 0; boxY <= 2; boxY++)//Loops through each column in the top row of the box
				{
					if(clearedRows == false)//Exits loop as soon as check fails
					{
						break;
					}
					int value = board[box][boxY][0];//Takes value from element in top row
					if(rowNumbersTop.contains(value))//Checks to make sure a number isn't used twice
					{
						rowNumbersTop.remove(Integer.valueOf(value));//Removes checked number
					}
					else//If number used twice
					{
						clearedRows = false;//Fails check
						break;//Exits loop
					}
				}
				for(int boxY = 0; boxY <= 2; boxY++)//Loops through each column in the middle row of the box
				{
					if(clearedRows == false)//Exits loop as soon as check fails
					{
						break;
					}
					int value = board[box][boxY][1];//Takes value from element in middle row
					if(rowNumbersMiddle.contains(value))//Checks to make sure a number isn't used twice
					{
						rowNumbersMiddle.remove(Integer.valueOf(value));//Removes checked number
					}
					else//If number used twice
					{
						clearedRows = false;//Fails check
						break;//Exits loop
					}
				}
				for(int boxY = 0; boxY <= 2; boxY++)//Loops through each column in the bottom row of the box
				{
					if(clearedRows == false)//Exits loop as soon as check fails
					{
						break;
					}
					int value = board[box][boxY][2];//Takes value from element in bottom row
					if(rowNumbersBottom.contains(value))//Checks to make sure a number isn't used twice
					{
						rowNumbersBottom.remove(Integer.valueOf(value));//Removes checked number
					}
					else//If number used twice
					{
						clearedRows = false;//Fails check
						break;//Exits loop
					}
				}
			}
			else if(box < 6)//Checks for middle 3 boxes
			{
				if(box == 3)//Initialize checkers on first loop
				{
					rowNumbersTop.addAll(sudokuNumbers);
					rowNumbersMiddle.addAll(sudokuNumbers);
					rowNumbersBottom.addAll(sudokuNumbers);//All get values 1 - 9 added to them
				}
				for(int boxY = 0; boxY <= 2; boxY++)//Loops through each column in the top row of the box
				{
					if(clearedRows == false)//Exits loop as soon as check fails
					{
						break;
					}
					int value = board[box][boxY][0];//Takes value from element in top row
					if(rowNumbersTop.contains(value))//Checks to make sure a number isn't used twice
					{
						rowNumbersTop.remove(Integer.valueOf(value));//Removes checked number
					}
					else//If number used twice
					{
						clearedRows = false;//Fails check
						break;//Exits loop
					}
				}
				for(int boxY = 0; boxY <= 2; boxY++)//Loops through each column in the middle row of the box
				{
					if(clearedRows == false)//Exits loop as soon as check fails
					{
						break;
					}
					int value = board[box][boxY][1];//Takes value from element in middle row
					if(rowNumbersMiddle.contains(value))//Checks to make sure a number isn't used twice
					{
						rowNumbersMiddle.remove(Integer.valueOf(value));//Removes checked number
					}
					else//If number used twice
					{
						clearedRows = false;//Fails check
						break;//Exits loop
					}
				}
				for(int boxY = 0; boxY <= 2; boxY++)//Loops through each column in the bottom row of the box
				{
					if(clearedRows == false)//Exits loop as soon as check fails
					{
						break;
					}
					int value = board[box][boxY][2];//Takes value from element in bottom row
					if(rowNumbersBottom.contains(value))//Checks to make sure a number isn't used twice
					{
						rowNumbersBottom.remove(Integer.valueOf(value));//Removes checked number
					}
					else//If number used twice
					{
						clearedRows = false;//Fails check
						break;//Exits loop
					}
				}
			}
			else if(box < 9)//Checks for bottom 3 boxes
			{
				if(box == 6)//Initialize checkers on first loop
				{
					rowNumbersTop.addAll(sudokuNumbers);
					rowNumbersMiddle.addAll(sudokuNumbers);
					rowNumbersBottom.addAll(sudokuNumbers);//All get values 1 - 9 added to them
				}
				for(int boxY = 0; boxY <= 2; boxY++)//Loops through each column in the top row of the box
				{
					if(clearedRows == false)//Exits loop as soon as check fails
					{
						break;
					}
					int value = board[box][boxY][0];//Takes value from element in top row
					if(rowNumbersTop.contains(value))//Checks to make sure a number isn't used twice
					{
						rowNumbersTop.remove(Integer.valueOf(value));//Removes checked number
					}
					else//If number used twice
					{
						clearedRows = false;//Fails check
						break;//Exits loop
					}
				}
				for(int boxY = 0; boxY <= 2; boxY++)//Loops through each column in the middle row of the box
				{
					if(clearedRows == false)//Exits loop as soon as check fails
					{
						break;
					}
					int value = board[box][boxY][1];//Takes value from element in middle row
					if(rowNumbersMiddle.contains(value))//Checks to make sure a number isn't used twice
					{
						rowNumbersMiddle.remove(Integer.valueOf(value));//Removes checked number
					}
					else//If number used twice
					{
						clearedRows = false;//Fails check
						break;//Exits loop
					}
				}
				for(int boxY = 0; boxY <= 2; boxY++)//Loops through each column in the bottom row of the box
				{
					if(clearedRows == false)//Exits loop as soon as check fails
					{
						break;
					}
					int value = board[box][boxY][2];//Takes value from element in bottom row
					if(rowNumbersBottom.contains(value))//Checks to make sure a number isn't used twice
					{
						rowNumbersBottom.remove(Integer.valueOf(value));//Removes checked number
					}
					else//If number used twice
					{
						clearedRows = false;//Fails check
						break;//Exits loop
					}
				}
			}
		}
		return clearedRows;
	}
	
	//Checks for valid Sudoku columns
	//Tested and Confirmed working as intended
	private static boolean checkColumns(int[][][] board)
	{
		boolean clearedColumns = true;//Assume columns pass
		ArrayList<Integer> columnNumbersLeft = new ArrayList<Integer>();//Used for checking all numbers 1 - 9 in left column
		ArrayList<Integer> columnNumbersMiddle = new ArrayList<Integer>();//Used for checking all numbers 1 - 9 in middle column
		ArrayList<Integer> columnNumbersRight = new ArrayList<Integer>();//Used for checking all numbers 1 - 9 in right column
		for(int box = 0; box <= 8; box += 3)//Loops through the 3 leftmost boxes
		{
			if(clearedColumns == false)//Exits loop as soon as check fails
			{
				break;
			}
			if(box == 0)//Initiate checkers on first loop
			{
				columnNumbersLeft.addAll(sudokuNumbers);
				columnNumbersMiddle.addAll(sudokuNumbers);
				columnNumbersRight.addAll(sudokuNumbers);//All get values 1 - 9 added to them
			}
			for(int boxX = 0; boxX <= 2; boxX++)//Loops through each row in the leftmost column
			{
				if(clearedColumns == false)//Exits loop as soon as check fails
				{
					break;
				}
				int value = board[box][0][boxX];//Takes value from element in leftmost column
				if(columnNumbersLeft.contains(value))//Checks to make sure a number isn't used twice
				{
					columnNumbersLeft.remove(Integer.valueOf(value));//Removes checked number
				}
				else//If number used twice
				{
					clearedColumns = false;//Fails check
					break;//Exits loop
				}
			}
			for(int boxX = 0; boxX <= 2; boxX++)//Loops through each row in the leftmost column
			{
				if(clearedColumns == false)//Exits loop as soon as check fails
				{
					break;
				}
				int value = board[box][1][boxX];//Takes value from element in the middle column
				if(columnNumbersMiddle.contains(value))//Checks to make sure a number isn't used twice
				{
					columnNumbersMiddle.remove(Integer.valueOf(value));//Removes checked number
				}
				else//If number used twice
				{
					clearedColumns = false;//Fails check
					break;//Exits loop
				}
			}
			for(int boxX = 0; boxX <= 2; boxX++)//Loops through each row in the leftmost column
			{
				if(clearedColumns == false)//Exits loop as soon as check fails
				{
					break;
				}
				int value = board[box][2][boxX];//Takes value from element in the middle column
				if(columnNumbersRight.contains(value))//Checks to make sure a number isn't used twice
				{
					columnNumbersRight.remove(Integer.valueOf(value));//Removes checked number
				}
				else//If number used twice
				{
					clearedColumns = false;//Fails check
					break;//Exits loop
				}
			}
		}
		for(int box = 1; box <= 8; box += 3)//Loops through the 3 middle boxes
		{
			if(clearedColumns == false)//Exits loop as soon as check fails
			{
				break;
			}
			if(box == 1)//Initiate checkers on first loop
			{
				columnNumbersLeft.addAll(sudokuNumbers);
				columnNumbersMiddle.addAll(sudokuNumbers);
				columnNumbersRight.addAll(sudokuNumbers);//All get values 1 - 9 added to them
			}
			for(int boxX = 0; boxX <= 2; boxX++)//Loops through each row in the leftmost column
			{
				if(clearedColumns == false)//Exits loop as soon as check fails
				{
					break;
				}
				int value = board[box][0][boxX];//Takes value from element in leftmost column
				if(columnNumbersLeft.contains(value))//Checks to make sure a number isn't used twice
				{
					columnNumbersLeft.remove(Integer.valueOf(value));//Removes checked number
				}
				else//If number used twice
				{
					clearedColumns = false;//Fails check
					break;//Exits loop
				}
			}
			for(int boxX = 0; boxX <= 2; boxX++)//Loops through each row in the leftmost column
			{
				if(clearedColumns == false)//Exits loop as soon as check fails
				{
					break;
				}
				int value = board[box][1][boxX];//Takes value from element in the middle column
				if(columnNumbersMiddle.contains(value))//Checks to make sure a number isn't used twice
				{
					columnNumbersMiddle.remove(Integer.valueOf(value));//Removes checked number
				}
				else//If number used twice
				{
					clearedColumns = false;//Fails check
					break;//Exits loop
				}
			}
			for(int boxX = 0; boxX <= 2; boxX++)//Loops through each row in the leftmost column
			{
				if(clearedColumns == false)//Exits loop as soon as check fails
				{
					break;
				}
				int value = board[box][2][boxX];//Takes value from element in the middle column
				if(columnNumbersRight.contains(value))//Checks to make sure a number isn't used twice
				{
					columnNumbersRight.remove(Integer.valueOf(value));//Removes checked number
				}
				else//If number used twice
				{
					clearedColumns = false;//Fails check
					break;//Exits loop
				}
			}
		}
		for(int box = 2; box <= 8; box += 3)//Loops through the 3 leftmost boxes
		{
			if(clearedColumns == false)//Exits loop as soon as check fails
			{
				break;
			}
			if(box == 2)//Initiate checkers on first loop
			{
				columnNumbersLeft.addAll(sudokuNumbers);
				columnNumbersMiddle.addAll(sudokuNumbers);
				columnNumbersRight.addAll(sudokuNumbers);//All get values 1 - 9 added to them
			}
			for(int boxX = 0; boxX <= 2; boxX++)//Loops through each row in the leftmost column
			{
				if(clearedColumns == false)//Exits loop as soon as check fails
				{
					break;
				}
				int value = board[box][0][boxX];//Takes value from element in leftmost column
				if(columnNumbersLeft.contains(value))//Checks to make sure a number isn't used twice
				{
					columnNumbersLeft.remove(Integer.valueOf(value));//Removes checked number
				}
				else//If number used twice
				{
					clearedColumns = false;//Fails check
					break;//Exits loop
				}
			}
			for(int boxX = 0; boxX <= 2; boxX++)//Loops through each row in the leftmost column
			{
				if(clearedColumns == false)//Exits loop as soon as check fails
				{
					break;
				}
				int value = board[box][1][boxX];//Takes value from element in the middle column
				if(columnNumbersMiddle.contains(value))//Checks to make sure a number isn't used twice
				{
					columnNumbersMiddle.remove(Integer.valueOf(value));//Removes checked number
				}
				else//If number used twice
				{
					clearedColumns = false;//Fails check
					break;//Exits loop
				}
			}
			for(int boxX = 0; boxX <= 2; boxX++)//Loops through each row in the leftmost column
			{
				if(clearedColumns == false)//Exits loop as soon as check fails
				{
					break;
				}
				int value = board[box][2][boxX];//Takes value from element in the middle column
				if(columnNumbersRight.contains(value))//Checks to make sure a number isn't used twice
				{
					columnNumbersRight.remove(Integer.valueOf(value));//Removes checked number
				}
				else//If number used twice
				{
					clearedColumns = false;//Fails check
					break;//Exits loop
				}
			}
		}
		return clearedColumns;
	}
}
