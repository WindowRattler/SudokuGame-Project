import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

class AutoSolve implements Runnable
{
	private TextField[][][] fieldArray;
	private SudokuGame game;
    private Button clearButton;
    private Button shuffleButton;
    private Button autoSolveButton;
    private Button checkButton;
    private Button saveButton;
    private Button loadButton;
	
	public AutoSolve(SudokuGame game, TextField[][][] fieldArray, Button clearButton, Button shuffleButton,
			Button autoSolveButton, Button checkButton, Button saveButton, Button loadButton)
	{
		this.game = game;
		this.fieldArray = fieldArray;
		this.clearButton = clearButton;
		this.shuffleButton = shuffleButton;
		this.autoSolveButton = autoSolveButton;
		this.checkButton = checkButton;
		this.saveButton = saveButton;
		this.loadButton = loadButton;
	}
	
	public void run()
	{
		autoSolve(0, 0, 0);
		activateButtons();
	}
	
	 //Recursively fills in zeroes
  	//Returns false if not solvable, else returns true
  	private boolean autoSolve(int box, int row, int column)
  	{
  		{
  			if(row > 2 && column < 2)//When at end of row
  			{
  				row = 0;//Reset row
  				column++;//Increment column
  			}
  			if(row > 2 && column >= 2)//When at end of row and end of column
  			{
  				row = 0;//reset row
  				column = 0;//reset column
  				box++;//increment box
  			}
  			if(box == 9)
  			{
  				return true;//Stop recursion
  			}
  			if(game.getBoard()[box][row][column] != 0)
  			{
  				return(autoSolve(box, row + 1, column));
  			}
  			for(int num = 1; num <= 9; num++)//Loop through 1 through 9
  			{
  				if(Rules.safeToPlace(game.getBoard(), box, row, column, num))//Checks if safe to place number
  				{
  					game.modifyElement(box, column, row, num);//Enter number into board
  					fieldArray[box][column][row].setText(Integer.toString(num));//Displays changes
  					try {
  						Thread.sleep(500);
  					} catch (InterruptedException e) {
  						// TODO Auto-generated catch block
  						e.printStackTrace();
  					}//Waits half a second
  					if(autoSolve(box, row + 1, column))
  						return true;
  					
  					game.modifyElement(box, column, row, 0);
  				}
  			}
  			return false;
  		}
  	}
  	
  	//Reactivates buttons disabled before thread was called
  	private void activateButtons()
  	{
  		clearButton.setDisable(false);
  		shuffleButton.setDisable(false);
  		autoSolveButton.setDisable(false);
  		checkButton.setDisable(false);
  		saveButton.setDisable(false);
  		loadButton.setDisable(false);
  	}
}
