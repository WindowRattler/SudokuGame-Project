import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
//Class for controlling the results screen
public class EndScreenController {

    @FXML
    private Button continueButton;

    @FXML
    private TextField statusText;

    @FXML
    private TextField descriptionText;

    private boolean clearedGame = false;//Flag for cleared game
    Time2 currentTime;//Time to display in results
    
    //Sets flag based on called controller
    public void initData(boolean clearedGame, Time2 currentTime)
    {
    	this.clearedGame = clearedGame;
    	this.currentTime = currentTime;
    	Initialize();
    }
    
    //Initializes message
    private void Initialize()
    {
    	//If game is cleared
    	if(clearedGame)
    	{
    		statusText.setText("You Win!");
    		descriptionText.setText("Clear time is: " + String.format("%02d:%02d:%02d", currentTime.getHour(), currentTime.getMinute(), currentTime.getSecond()));
    	}
    	else
    	{
    		statusText.setText("Game is not Cleared.");
    		descriptionText.setText("Try Again.");
    	}
    }
    
    @FXML
    void buttonClicked(ActionEvent event) {
    	// get a handle to the stage
        Stage stage = (Stage) continueButton.getScene().getWindow();
        //Close stage
        stage.close();
    }
}
