//Class for keeping track of the time elapsed during the sudoku game
import java.util.Timer;
import java.util.TimerTask;

public class TimeKeeper extends TimerTask {
	Time2 currentTime;
	public TimeKeeper(Time2 currentTime)
	{
		this.currentTime = currentTime;
	}
	
	public void run()
	{
		currentTime.tick();//Increments time by one second
	}
}
