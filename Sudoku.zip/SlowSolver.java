//Solves the board in a manner that shows each move
public class SlowSolver extends Solver {
	
	public static void slowSolve(int [][][] baseBoard)
	{
		ArrayCopier.copyArray(baseBoard, workingBoard);
		if(fillEmpty(0, 0, 0))
		{
			System.out.println("Success");
		}
	}
	
	
	//Recursively fills in zeroes
	//Returns false if not solvable, else returns true
	protected static boolean fillEmpty(int box, int row, int column)
	{
		{
			if(row > 2 && column < 2)//When at end of row
			{
				row = 0;//Reset row
				column++;//Increment column
			}
			if(row > 2 && column >= 2)//When at end of row and end of column
			{
				row = 0;//reset row
				column = 0;//reset column
				box++;//increment box
			}
			if(box == 9)
			{
				return true;//Stop recursion
			}
			if(workingBoard[box][row][column] != 0)
			{
				return(fillEmpty(box, row + 1, column));
			}
			for(int num = 1; num <= 9; num++)//Loop through 1 through 9
			{
				if(Rules.safeToPlace(workingBoard, box, row, column, num))//Checks if safe to place number
				{
					workingBoard[box][row][column] = num;//Enter number into board
					printArray();//Displays changes
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}//Waits half a second
					if(fillEmpty(box, row + 1, column))
						return true;
					
					workingBoard[box][row][column] = 0;
				}
			}
			return false;
		}
	}
	
	private static void printArray()//Prints the array
	{
		for(int box = 0; box <= 2; box++)//Prints first 3 boxes top row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(workingBoard[box][boxY][0]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 2)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		for(int box = 0; box <= 2; box++)//Prints first 3 boxes middle row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(workingBoard[box][boxY][1]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 2)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		for(int box = 0; box <= 2; box++)//Prints first 3 boxes bottom row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(workingBoard[box][boxY][2]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 2)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		System.out.println();//Space between boxes
		for(int box = 3; box <= 5; box++)//Prints middle 3 boxes top row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(workingBoard[box][boxY][0]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 5)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		for(int box = 3; box <= 5; box++)//Prints middle 3 boxes middle row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(workingBoard[box][boxY][1]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 5)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		for(int box = 3; box <= 5; box++)//Prints middle 3 boxes bottom row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(workingBoard[box][boxY][2]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 5)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		System.out.println();//Space between boxes
		for(int box = 6; box <= 8; box++)//Prints bottom 3 boxes top row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(workingBoard[box][boxY][0]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 8)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		for(int box = 6; box <= 8; box++)//Prints bottom 3 boxes middle row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(workingBoard[box][boxY][1]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 8)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		for(int box = 6; box <= 8; box++)//Prints bottom 3 boxes bottom row
		{
			for(int boxY = 0; boxY <= 2; boxY++)
			{
					System.out.print(workingBoard[box][boxY][2]);
					if(boxY == 2)
						System.out.print(" | ");//Adds a line every 3 elements
					System.out.print(" ");//Space between elements
			}
			if(box == 8)
			{
				System.out.print("\n");//Newline at end of row
			}
		}
		System.out.println();//Space between boxes
	}

}
