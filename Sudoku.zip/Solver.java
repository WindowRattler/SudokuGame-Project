//Solves partial Sudoku games recursively
//Tells if no solution
public class Solver extends Rules {
	protected static int workingBoard[][][] = new int[9][3][3];//For working with
	private static int finishedBoard[][][] = new int[9][3][3];//Completed board

	//Returns a solved board, or tells if board is unsolvable
	public static int[][][] solve(int[][][] baseBoard)
	{
		ArrayCopier.copyArray(baseBoard, workingBoard);
		int count = fillEmpty(0, 0, 0, 0);
		//For debug
		//System.out.println(count);
		if(count == 1)
		{
			//Returns completed board
			return finishedBoard;
		}
		else if(count < 1)
		{
			//Returns original board
			//TODO make some manner of telling that there is no solution
			return baseBoard;
		}
		else
		{
			//Returns original board
			//TODO make some manner of telling that the board has no unique solution
			return baseBoard;
		}
	}
	
	//Returns number of solutions to a board
	public static int solve(int[][][] baseBoard, boolean isSolvable)
	{
		ArrayCopier.copyArray(baseBoard, workingBoard);
		int count = fillEmpty(0, 0, 0, 0);
		return count;
	}
	
	//Recursively fills in zeroes
	//Returns 0 if not solvable, else returns number of solutions
	protected static int fillEmpty(int box, int row, int column, int count)//Count must start at 0
	{
		if(row > 2 && column < 2)//When at end of row
		{
			row = 0;//Reset row
			column++;//Increment column
		}
		if(row > 2 && column >= 2)//When at end of row and end of column
		{
			row = 0;//reset row
			column = 0;//reset column
			box++;//increment box
		}
		if(box == 9)
		{
			if(count == 0)
			{
				ArrayCopier.copyArray(workingBoard, finishedBoard);//Stores completed board
			}
			return (1 + count);//Stop current recursion
		}
		if(workingBoard[box][row][column] != 0)//Skips filled cells
		{
			return fillEmpty(box, row + 1, column, count);
		}
		//Looks for multiple solutions
		//Stops if 2 or more are found
			for(int num = 1; num <= 9 && count < 2; num++)//Loop through 1 through 9
			{
				if(safeToPlace(workingBoard, box, row, column, num))//Checks if safe to place number
				{
					workingBoard[box][row][column] = num;//Enter number into board
					//For debug
					//printArray();
					count = fillEmpty(box, row + 1, column, count);
				}
			}
			workingBoard[box][row][column] = 0;//Reset on backtrack
			return count;
		}
	}
