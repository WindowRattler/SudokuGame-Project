//Deep copies 3D int arrays of same size
public class ArrayCopier {

	public static void copyArray(int[][][] src, int[][][] dest) throws ArrayIndexOutOfBoundsException, ArrayStoreException
	{
		for(int i = 0; i < src.length; i++)
		{
			for(int j = 0; j < src[i].length; j++)
			{
				for(int k = 0; k < src[i][j].length; k++)
				{
					dest[i][j][k] = src[i][j][k];
				}
			}
			
		}
	}
}
