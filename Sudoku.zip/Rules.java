//Rules for sudoku number placement
public class Rules {
	//Checks if number not used in row
	private static boolean unUsedInRow(int [][][] board, int box, int col, int number)
	{
		boolean unused = true;//Assume unused
		int checkedValue;//Used for storing the value to check
		//Top three boxes
		if(box < 3)
		{
			for(int loopBox = 0; loopBox < 3; loopBox++)//Loops through boxes
			{
				if(loopBox == box)//Ignores box checked for
				{
					continue;
				}
				for(int row = 0; row < 3; row++)//Loops through columns
				{
					checkedValue = board[loopBox][row][col];
					if(checkedValue == number)
					{
						unused = false;//Sets flag as used
						return unused;//Returns flag
					}
				}
			}
		}
		//Middle three boxes
		else if(box < 6)
		{
			for(int loopBox = 3; loopBox < 6; loopBox++)//Loops through boxes
			{
				if(loopBox == box)//Ignores box checked for
				{
					continue;
				}
				for(int row = 0; row < 3; row++)//Loops through columns
				{
					checkedValue = board[loopBox][row][col];
					if(checkedValue == number)
					{
						unused = false;//Sets flag as used
						return unused;//Returns flag
					}
				}
			}
		}
		//Bottom three boxes
		else if(box < 9)
		{
			for(int loopBox = 6; loopBox < 9; loopBox++)//Loops through boxes
			{
				if(loopBox == box)//Ignores box checked for
				{
					continue;
				}
				for(int row = 0; row < 3; row++)//Loops through columns
				{
					checkedValue = board[loopBox][row][col];
					if(checkedValue == number)
					{
						unused = false;//Sets flag as used
						return unused;//Returns flag
					}
				}
			}
		}
		return unused;//Should always return true
	}
	
	//Checks if number not used in column
	private static boolean unUsedInCol(int[][][] board, int box, int row, int number)
	{
		boolean unused = true;//Assume unused
		int checkedValue;//Stores value to check
		//Left three boxes
		if(box % 3 == 0)
		{
			for(int loopBox = 0; loopBox < 9; loopBox += 3)//Loops through boxes
			{
				if(loopBox == box)//Ignores box checked for
				{
					continue;
				}
				for(int col = 0; col < 3; col++)//Loops through rows
				{
					checkedValue = board[loopBox][row][col];
					if(checkedValue == number)
					{
						unused = false;//Sets flag as used
						return unused;//Returns flag
					}
				}
			}
		}
		//Middle three boxes
		else if(box % 3 == 1)
		{
			for(int loopBox = 1; loopBox < 9; loopBox += 3)//Loops through boxes
			{
				if(loopBox == box)//Ignores box checked for
				{
					continue;
				}
				for(int col = 0; col < 3; col++)//Loops through rows
				{
					checkedValue = board[loopBox][row][col];
					if(checkedValue == number)
					{
						unused = false;//Sets flag as used
						return unused;//Returns flag
					}
				}
			}
		}
		//Right three boxes
		else if(box % 3 == 2)
		{
			for(int loopBox = 2; loopBox < 9; loopBox += 3)//Loops through boxes
			{
				if(loopBox == box)//Ignores box checked for
				{
					continue;
				}
				for(int col = 0; col < 3; col++)//Loops through rows
				{
					checkedValue = board[loopBox][row][col];
					if(checkedValue == number)
					{
						unused = false;//Sets flag as used
						return unused;//Returns flag
					}
				}
			}
		}
		return unused;//Should always return true
	}
	
	private static boolean unUsedInBox(int[][][] board, int box, int number)
	{
		boolean unused = true;//Assume unused
		int checkedValue;//Stores value to check
		for(int row = 0; row <= 2; row++)//Loop through row
		{
			for(int column = 0; column <= 2; column++)//Loop through column
			{
				checkedValue = board[box][row][column];
				if(checkedValue == number)
				{
					unused = false;
					return unused;
				}
			}
		}
		return unused;//Should always be true
	}
	
	//Checks if safe to put in box, row, and column
	public static boolean safeToPlace(int[][][] board, int box, int row, int col, int num)
	{
		if(unUsedInBox(board, box, num) && unUsedInRow(board, box, col, num) && unUsedInCol(board, box, row, num))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
