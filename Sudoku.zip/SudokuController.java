import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Timer;
import java.time.LocalDateTime;
import javafx.application.Platform;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;

public class SudokuController {
	
	@FXML
    private TextField timerField;
	
    @FXML
    private TextArea descriptionTextArea;

    @FXML
    private Button clearButton;

    @FXML
    private Button shuffleButton;

    @FXML
    private Button autoSolveButton;

    @FXML
    private Button checkButton;

    @FXML
    private Button saveButton;

    @FXML
    private Button loadButton;

    @FXML
    private TextField box0X0Y0;

    @FXML
    private TextField box0X0Y1;

    @FXML
    private TextField box0X0Y2;

    @FXML
    private TextField box1X0Y0;

    @FXML
    private TextField box1X0Y1;

    @FXML
    private TextField box1X0Y2;

    @FXML
    private TextField box2X0Y0;

    @FXML
    private TextField box2X0Y1;

    @FXML
    private TextField box2X0Y2;

    @FXML
    private TextField box0X1Y0;

    @FXML
    private TextField box0X1Y1;

    @FXML
    private TextField box0X1Y2;

    @FXML
    private TextField box1X1Y0;

    @FXML
    private TextField box1X1Y1;

    @FXML
    private TextField box1X1Y2;

    @FXML
    private TextField box2X2Y2;

    @FXML
    private TextField box2X1Y2;

    @FXML
    private TextField box0X2Y0;

    @FXML
    private TextField box0X2Y1;

    @FXML
    private TextField box0X2Y2;

    @FXML
    private TextField box1X2Y0;

    @FXML
    private TextField box1X2Y1;

    @FXML
    private TextField box1X2Y2;

    @FXML
    private TextField box2X2Y0;

    @FXML
    private TextField box2X2Y1;

    @FXML
    private TextField box2X1Y0;

    @FXML
    private TextField box2X1Y1;

    @FXML
    private TextField box5X0Y2;

    @FXML
    private TextField box5X1Y2;

    @FXML
    private TextField box5X2Y2;

    @FXML
    private TextField box8X0Y2;

    @FXML
    private TextField box8X1Y2;

    @FXML
    private TextField box8X2Y2;

    @FXML
    private TextField box5X0Y1;

    @FXML
    private TextField box5X1Y1;

    @FXML
    private TextField box5X2Y1;

    @FXML
    private TextField box8X0Y1;

    @FXML
    private TextField box8X1Y1;

    @FXML
    private TextField box8X2Y1;

    @FXML
    private TextField box5X0Y0;

    @FXML
    private TextField box5X1Y0;

    @FXML
    private TextField box5X2Y0;

    @FXML
    private TextField box8X0Y0;

    @FXML
    private TextField box8X1Y0;

    @FXML
    private TextField box8X2Y0;

    @FXML
    private TextField box4X0Y2;

    @FXML
    private TextField box4X1Y2;

    @FXML
    private TextField box4X2Y2;

    @FXML
    private TextField box7X0Y2;

    @FXML
    private TextField box7X1Y2;

    @FXML
    private TextField box7X2Y2;

    @FXML
    private TextField box4X0Y1;

    @FXML
    private TextField box4X0Y0;

    @FXML
    private TextField box3X0Y2;

    @FXML
    private TextField box3X0Y1;

    @FXML
    private TextField box3X0Y0;

    @FXML
    private TextField box3X1Y0;

    @FXML
    private TextField box3X1Y1;

    @FXML
    private TextField box3X1Y2;

    @FXML
    private TextField box4X1Y0;

    @FXML
    private TextField box4X1Y1;

    @FXML
    private TextField box4X2Y1;

    @FXML
    private TextField box7X0Y1;

    @FXML
    private TextField box7X1Y1;

    @FXML
    private TextField box7X2Y1;

    @FXML
    private TextField box7X2Y0;

    @FXML
    private TextField box6X2Y2;

    @FXML
    private TextField box6X2Y1;

    @FXML
    private TextField box6X2Y0;

    @FXML
    private TextField box6X1Y0;

    @FXML
    private TextField box6X0Y0;

    @FXML
    private TextField box3X2Y0;

    @FXML
    private TextField box3X2Y1;

    @FXML
    private TextField box6X0Y1;

    @FXML
    private TextField box6X1Y1;

    @FXML
    private TextField box6X1Y2;

    @FXML
    private TextField box6X0Y2;

    @FXML
    private TextField box3X2Y2;

    @FXML
    private TextField box4X2Y0;

    @FXML
    private TextField box7X0Y0;

    @FXML
    private TextField box7X1Y0;
    
    //3D array of textfields for integration with the game
    @FXML
    private TextField[][][] fieldArray;
    
    //Listener to prevent any values not between 1 and 9
    public ChangeListener<String> numbericListener = new ChangeListener<String>() {
    	@Override
        public void changed(ObservableValue<? extends String> observable, String oldValue, 
            String newValue) {
    		StringProperty textProperty = (StringProperty) observable ;
    		TextField textField = (TextField) textProperty.getBean();
            if (!newValue.matches("[1-9]")) {
            	Platform.runLater(() ->textField.setText("0"));
            }
        }
    };
    
    SudokuGame game;
    int difficulty = 1;
    Stage mainStage;//Current stage
    
    
    Time2 startTime = new Time2(0, 0, 0);
    Time2 currentTime = new Time2(startTime);//Creates objects for keeping track of time passed
    Timer incrementTime = new Timer();//Creates timer for increasing time
    Timer timeUpdater = new Timer();//Creates timer for updating the textfield
    TimeKeeper timeKeeper;//TimerTask object
    TimeCompare timeCompare;//TimerTask object
    
    //Intialize difficulty and game
    public void initData(int difficulty, Stage stage)
    {
    	this.difficulty = difficulty;
    	this.mainStage = stage;
    	initialize();
    }
    
    //Initialize method
    //private because initData must be called first
    private void initialize()
    {
    	game = new SudokuGame(difficulty);
    	fieldArray = new TextField[][][] 
        	{ { {box0X0Y0, box0X0Y1, box0X0Y2}, {box0X1Y0, box0X1Y1, box0X1Y2}, {box0X2Y0, box0X2Y1, box0X2Y2} },
        	  { {box1X0Y0, box1X0Y1, box1X0Y2}, {box1X1Y0, box1X1Y1, box1X1Y2}, {box1X2Y0, box1X2Y1, box1X2Y2} },
        	  { {box2X0Y0, box2X0Y1, box2X0Y2}, {box2X1Y0, box2X1Y1, box2X1Y2}, {box2X2Y0, box2X2Y1, box2X2Y2} },
        	  { {box3X0Y0, box3X0Y1, box3X0Y2}, {box3X1Y0, box3X1Y1, box3X1Y2}, {box3X2Y0, box3X2Y1, box3X2Y2} },
        	  { {box4X0Y0, box4X0Y1, box4X0Y2}, {box4X1Y0, box4X1Y1, box4X1Y2}, {box4X2Y0, box4X2Y1, box4X2Y2} },
        	  { {box5X0Y0, box5X0Y1, box5X0Y2}, {box5X1Y0, box5X1Y1, box5X1Y2}, {box5X2Y0, box5X2Y1, box5X2Y2} },
        	  { {box6X0Y0, box6X0Y1, box6X0Y2}, {box6X1Y0, box6X1Y1, box6X1Y2}, {box6X2Y0, box6X2Y1, box6X2Y2} },
        	  { {box7X0Y0, box7X0Y1, box7X0Y2}, {box7X1Y0, box7X1Y1, box7X1Y2}, {box7X2Y0, box7X2Y1, box7X2Y2} },
        	  { {box8X0Y0, box8X0Y1, box8X0Y2}, {box8X1Y0, box8X1Y1, box8X1Y2}, {box8X2Y0, box8X2Y1, box8X2Y2} }
        	};
    	modifyEditable();
    	bindElements();
    	attachListener();
    	if(difficulty == 5)
    	{
    		autoSolveButton.setDisable(true);//Disable auto solve button if game is hard to avoid errors
    	}
    	timeKeeper = new TimeKeeper(currentTime);
    	incrementTime.scheduleAtFixedRate(timeKeeper, 0, 1000);//Increments current time by 1 second every second
    	timeCompare = new TimeCompare(currentTime, startTime, timerField);
    	timeUpdater.scheduleAtFixedRate(timeCompare, 0, 500);//Updates timer textfield every second
    	
    	//Set application close to properly close threads
    	mainStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
    		@Override
    		public void handle(WindowEvent e) {
    			//Close threads
    			incrementTime.cancel();
    			timeUpdater.cancel();
    			Platform.exit();
    			System.exit(0);
    		}
    	});
    }
    
    //Attaches a listener that rejects numbers not between 1 and 9
    private void attachListener()
    {
    	//Loops through textfields
    	for(int box = 0; box < 9; box++)
		{
			for(int x = 0; x < 3; x++)
			{
				for(int y = 0; y < 3; y++)
				{
					fieldArray[box][x][y].textProperty().addListener(numbericListener);
				}
			}
		}
    }
    
    //Sets elements as editable if they contain 0
    private void modifyEditable()
    {
    	//Loop through editable array from sudokugame
    	for(int box = 0; box < 9; box++)
		{
			for(int x = 0; x < 3; x++)
			{
				for(int y = 0; y < 3; y++)
				{
					if(game.getEditable()[box][x][y])
					{
						//Allow textfield in space to be edited
						fieldArray[box][y][x].setEditable(true);
						fieldArray[box][y][x].setStyle("-fx-control-inner-background: #FFFFFF");//Editable is white
					}
					else
					{
						//Don't allow textfield in space to be edited
						fieldArray[box][y][x].setEditable(false);
						fieldArray[box][y][x].setStyle("-fx-control-inner-background: #A39E9E");//Not editable is gray
					}
				}
			}
		}
    }

    //Binds textfields to element in the same space on board
    private void bindElements()
    {
    	//Loop through board array from sudokugame
    	for(int box = 0; box < 9; box++)
		{
			for(int x = 0; x < 3; x++)
			{
				for(int y = 0; y < 3; y++)
				{
					fieldArray[box][y][x].setText(Integer.toString(game.getBoard()[box][x][y]));//TODO see if it can be binded instead
				}
			}
		}
    }

    //Resets the board to initial conditions
    private void startOver()
    {
    	//Reset game board to its starting state
    	game.setBoard(game.getStartBoard());
    	//Loop through board array from sudokugame
    	for(int box = 0; box < 9; box++)
		{
			for(int x = 0; x < 3; x++)
			{
				for(int y = 0; y < 3; y++)
				{
					fieldArray[box][y][x].setText(Integer.toString(game.getStartBoard()[box][x][y]));
				}
			}
		}
    }
    
    //Changes game board to match changes made
    private void modifyBoard()
    {
    	//Loop through fieldarray
    	for(int box = 0; box < 9; box++)
		{
			for(int x = 0; x < 3; x++)
			{
				for(int y = 0; y < 3; y++)
				{
					game.modifyElement(box, x, y, Integer.parseInt(fieldArray[box][x][y].getText()));
				}
			}
		}
    }
    
    @FXML
    void autoSolveButtonMouseOver(MouseEvent event) {
    	descriptionTextArea.setText("Solves the game one box at a time.\nPauses after each move so that it can be watched.\nButton is disabled in hard mode.");
    }

    @FXML
    void buttonMouseExit(MouseEvent event) {
    	descriptionTextArea.setText("Each box, row, and column must use the numbers 1 - 9 once.\nWhite boxes are editable, gray boxes are not.\nScroll over buttons to get a description of them.\nAuto-solve is not available in hard mode.");
    }
    
    @FXML
    void checkButtonMouseOver(MouseEvent event) {
    	descriptionTextArea.setText("Checks whether the current game is correct or not.");
    }
    
    @FXML
    void clearButtonMouseOver(MouseEvent event) {
    	descriptionTextArea.setText("Resets any changes to the current game.");
    }
    
    @FXML
    void loadButtonMouseOver(MouseEvent event) {
    	descriptionTextArea.setText("Loads the previously saved game.\nNote that only one game may be saved at a time.");
    }
    
    @FXML
    void saveButtonMouseOver(MouseEvent event) {
    	descriptionTextArea.setText("Saves the current game.\nOnly one game may be saved at a time.");
    }
    
    @FXML
    void shuffleButtonMouseOver(MouseEvent event) {
    	descriptionTextArea.setText("Returns to the difficulty selection screen to start a new game.");
    }
    
    @FXML
    void autoSolveButtonClicked(ActionEvent event) {
    	//Create class for multithread
    	AutoSolve solve = new AutoSolve(game, fieldArray, clearButton, shuffleButton, autoSolveButton, checkButton, saveButton, loadButton);
    	Thread solver = new Thread(solve);
    	//Prevent buttons from being pressed while thread is running
    	disableButtons();
    	solver.start();
    	timeCompare.cancel();
    	timerField.setText("Invalid");
    }

    @FXML
    void checkButtonClicked(ActionEvent event) {
    	//Start opening end screen
    	try
    	{
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("End Screen.fxml"));
    		Parent root1 = (Parent) fxmlLoader.load();
    		Stage stage = new Stage();
    		stage.initModality(Modality.APPLICATION_MODAL);
    		stage.initStyle(StageStyle.DECORATED);
    		stage.setTitle("Results");
    		stage.getIcons().add(new Image("Sudoku.png"));
    		//Check whether game is won
    		modifyBoard();
    		if(SudokuChecker.boardChecker(game.getBoard()))//TODO make this do something in the GUI
    		{
    			//Passes on cleared boolean and current time
        		fxmlLoader.<EndScreenController>getController().initData(true, currentTime);
        		stage.setScene(new Scene(root1));
    		}
    		else
    		{
    			//Passes on not cleared boolean
        		fxmlLoader.<EndScreenController>getController().initData(false, currentTime);
        		stage.setScene(new Scene(root1));
    		}
    		stage.show();//Displays stage
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    }

    @FXML
    void clearButtonClicked(ActionEvent event) {
    	startOver();
    }

    @FXML
    void loadButtonClicked(ActionEvent event) {
    	readBoardFromFile();
    	timeCompare.cancel();
    	timerField.setText("Invalid");
    }

    @FXML
    void saveButtonClicked(ActionEvent event) {
    	modifyBoard();
    	writeBoardToFile();
    }

    @FXML
    void shuffleButtonClicked(ActionEvent event) {
    	try {
    		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Difficulty Selector.fxml"));
    		Parent root1 = (Parent) fxmlLoader.load();
    		Stage stage = new Stage();
    		stage.initModality(Modality.APPLICATION_MODAL);
    		stage.initStyle(StageStyle.DECORATED);
    		stage.setTitle("Sudoku");
    		stage.getIcons().add(new Image("Sudoku.png"));
    		stage.setScene(new Scene(root1));  
    		stage.show();
    		// Hide this current window
            ((Node)(event.getSource())).getScene().getWindow().hide();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    }
    
    //Makes all buttons non-interactable
    private void disableButtons()
    {
    	clearButton.setDisable(true);
  		shuffleButton.setDisable(true);
  		autoSolveButton.setDisable(true);
  		checkButton.setDisable(true);
  		saveButton.setDisable(true);
  		loadButton.setDisable(true);
    }
    
    //Writes the board, fullBoard, and startBoard to file
    private void writeBoardToFile()
    {
    	try {
			BufferedWriter outputWriter = new BufferedWriter(new FileWriter("game.txt"));
			//Loop through board
			for(int box = 0; box < 9; box++)
			{
				for(int row = 0; row < 3; row++)
				{
					for(int col = 0; col < 3; col++)
					{
						outputWriter.write(Integer.toString(game.getBoard()[box][row][col]));
					}
				}
			}
			outputWriter.newLine();
			//Loop through startBoard
			for(int box = 0; box < 9; box++)
			{
				for(int row = 0; row < 3; row++)
				{
					for(int col = 0; col < 3; col++)
					{
						outputWriter.write(Integer.toString(game.getStartBoard()[box][row][col]));
					}
				}
			}
			outputWriter.newLine();
			//Loop through fullBoard
			for(int box = 0; box < 9; box++)
			{
				for(int row = 0; row < 3; row++)
				{
					for(int col = 0; col < 3; col++)
					{
						outputWriter.write(Integer.toString(game.getFullBoard()[box][row][col]));
					}
				}
			}
			outputWriter.flush();
			outputWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    //Reads the board, fullBoard, and startBoard from file and implements into the game
    private void readBoardFromFile()//TODO invalidate timer
    {
    	int[][][] board = new int[9][3][3];
    	String boardString;
    	int[][][] startBoard= new int[9][3][3];
    	String startBoardString;
    	int[][][]fullBoard= new int[9][3][3];
    	String fullBoardString;
    	//Read strings
    	try {
    		File file = new File("game.txt");
			Scanner scanner = new Scanner(file);
			boardString = scanner.nextLine();
			startBoardString = scanner.nextLine();
			fullBoardString = scanner.nextLine();
			scanner.close();
			//Integers for applying characters at the string index
			int i = 0;
			int j = 0;
			int k = 0;
			//Loop through boards
			for(int box = 0; box < 9; box++)
			{
				for(int row = 0; row < 3; row++)
				{
					for(int col = 0; col < 3; col++)
					{
						board[box][row][col] = Character.getNumericValue((boardString.charAt(i++)));
						startBoard[box][row][col] = Character.getNumericValue((startBoardString.charAt(j++)));
						fullBoard[box][row][col] = Character.getNumericValue((fullBoardString.charAt(k++)));
					}
				}
			}
			//Send boards to game
			game.setBoard(board);
			game.setStartBoard(startBoard);
			game.setFullBoard(fullBoard);
			game.makeEditableArray();
			//Update GUI
			modifyEditable();
	    	bindElements();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.err.println("File not Found");
		}
    }
}